export RISCV=/home/boom/projects/hd/riscv-multilib-toolchain
export PATH=$PATH:$RISCV/bin
#export ROCKETCHIP=/home/bergura/rocket-chip
